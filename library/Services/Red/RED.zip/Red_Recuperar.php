<?php
class Red_Recuperar extends Red_Abstract implements Red_Interface
{
	const SERVER_PRD            = 'prd.trf1.gov.br';
	const SERVER_DSV            = '172.16.3.179';
	public $numeroDocumento	    = '153750100238';
	//public $numeroDocumento	    = '41600100232';
	public $statusDoc			= 0;
	public $statusDocEntrada	= 0;
	public $login				= 'TR224PS';
	//public $ip					= '172.16.3.179';
	public $ip					= '172.16.5.62';
	public $server				= 'prd.trf1.gov.br';
	
	//public $server				= '172.16.5.62';
	//public $server				= '172.16.3.179'; //desenvolvimento
	public $sistema			    = 'JURIS';
	public $txTerro 			= '';
	public $erro 				= false;
	public $xmlSaida 			= '';
	public $xmlCaminhoEntrada	= ''; 
	public $urlSaida 			= array();
	public $mensagem			= array(); 
	public $existeArquivo		= true; 
	public $nomeMaquina         = '';
	public $urlRed 			    = '';//http://' . $this->server . '/REDCentral/autorizacaoRecuperacaoDocumento';
	
	public $parametros;

	public function __construct($desenvolvimento = false)
	{
		if ($desenvolvimento) {
			$this->server = self::SERVER_DSV;
			$this->debug = true;
		} 
		
		$this->urlRed = 'http://' . $this->server . '/REDCentral/autorizacaoRecuperacaoDocumento';
	}
	/*
	public function getXmlAutorizacao()
	{
		$doc = new DOMDocument();
		$root = $doc->createElement('root');
		$doc->appendChild($root);

		$solicitanteArquivo = $doc->createElement('solicitanteArquivo');
		$root->appendChild($solicitanteArquivo); 
		
		$numeroDocumento = $doc->createAttribute('numeroDocumento');
		$solicitanteArquivo->appendChild($numeroDocumento);
		$numeroDocumentoTexto = $doc->createTextNode($this->numeroDocumento);
    	$numeroDocumento->appendChild($numeroDocumentoTexto); 
    	
		$login = $doc->createAttribute('login');
		$solicitanteArquivo->appendChild($login);
		$loginTexto = $doc->createTextNode($this->login);
    	$login->appendChild($loginTexto);

		$ip = $doc->createAttribute('ip');
		$solicitanteArquivo->appendChild($ip);
		$ipTexto = $doc->createTextNode($this->ip);
    	$ip->appendChild($ipTexto);

		$sistema = $doc->createAttribute('sistema');
		$solicitanteArquivo->appendChild($sistema);
		$sistemaTexto = $doc->createTextNode($this->sistema);
    	$sistema->appendChild($sistemaTexto);

		$nomeMaquina = $doc->createAttribute('nomeMaquina');
		$solicitanteArquivo->appendChild($nomeMaquina);
		$nomeMaquinaTexto = $doc->createTextNode($this->nomeMaquina);
    	$nomeMaquina->appendChild($nomeMaquinaTexto);        	
    	
		return $doc->saveXML($root); 
		//return $doc->saveXML(); 
	}
	*/
	public function getAutorizacao ()
	{
		//$xml = $this->_getAutorizacao($this->urlRed,$this->getXmlAutorizacao());
		$xml = $this->_getAutorizacao($this->urlRed,$this->parametros->getXml());
		$obj = simplexml_load_string($xml);
		
		if (isset($obj->Mensagem)) {
			throw new Exception('Erro: ' . $obj->Mensagem['codigo'] . ' - ' . $obj->Mensagem['descricao']);
		}
		
		return array(
			'tipoArquivo' => (string)$obj->retornoListaURLArquivoDocumentoXML->retornoURLArquivoDocumentoXML['tipoArquivo'],
			'url'         => (string)$obj->retornoListaURLArquivoDocumentoXML->retornoURLArquivoDocumentoXML['url']
		);
	}
	
	public function recuperar (Red_Parametros_Interface $parametros)
	{
		$this->parametros = $parametros;
		
		try {
			return $this->getAutorizacao();
		} catch (Exception $e) {
			var_dump($e);
		}
	} 
	/*
	public function parseXml()
	{
		$obj = simplexml_load_string($this->xmlSaida);
		if (isset($obj->Mensagem)) {
			//echo 'erro';
			$this->erro = true;
			return false;
		} else {
			return $this->montarRetorno();
		}
	}
	
	public function getErros()
	{
		$obj = simplexml_load_string($this->xmlSaida);
		for($i=0; $i < sizeof($obj->Mensagem); $i++) {
			$retorno[] = array(
				'codigo'    => $obj->Mensagem[$i]['codigo'],
				'descricao' => $obj->Mensagem[$i]['descricao']
			);
		}
		
		return $retorno;
	}	
	*/
	public function montarRetorno()
	{
		return null;
		/*
		$obj = simplexml_load_string($this->xmlSaida);
		for($i=0; $i < sizeof($obj->retornoListaURLArquivoDocumentoXML->retornoURLArquivoDocumentoXML); $i++) {
			$retorno[] = array(
				'tipoArquivo' => $obj->retornoListaURLArquivoDocumentoXML->retornoURLArquivoDocumentoXML[$i]['tipoArquivo'],
				'url'         => $obj->retornoListaURLArquivoDocumentoXML->retornoURLArquivoDocumentoXML[$i]['url']
			);
		}
		
		return $retorno;
		*/
	}	
	
}
?>