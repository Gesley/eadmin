<?php
class Red_Incluir extends Red_Abstract implements Red_Interface
{
	const SERVER_PRD    = 'prd.trf1.gov.br';
	const SERVER_DSV  = '172.16.3.179'; 
	//const SERVER_DSV    = '172.16.4.153'; 
	
	public $login		= 'TR224PS';
	public $ip			= '172.16.5.62';
	public $server		= 'prd.trf1.gov.br'; //desenvolvimento
	public $sistema		= 'JURIS';
	public $nomeMaquina = '';
	
	public $xmlSaida 	= '';
	public $urlSaida 	= array();
	public $mensagem	= array(); 
	//public $nomeMaquina         = '';
	public $urlRed 		= '';//http://' . $this->server . '/REDCentral/autorizacaoRecuperacaoDocumento';
	
	public $dataHoraProducaoConteudo          = "30/01/2008 11:15:00";
	public $descricaoTituloDocumento          = "Primeiro teste inclusao1";
	public $numeroTipoSigilo                  = "01";
	public $numeroTipoDocumento               = "01";
	public $nomeSistemaIntrodutor             = "JURIS";
	public $ipMaquinaResponsavelIntervencao   = "172.16.5.62"; 
	public $secaoOrigemDocumento              = "0100";
	public $prioridadeReplicacao              = "N";
	public $espacoDocumento                   = "I";
	public $nomeMaquinaResponsavelIntervensao = "DIESP07";
	public $indicadorAnotacao                 = "";
	public $numeroDocumento                   = "";
	public $dataHoraProtocolo                 = "30/01/2008 11:15:00";
	public $pastaProcessoNumero               = "12345";
	public $secaoDestinoIdSecao               = "0100";
	
	public $parametros;
	public $metadados;
	
	

	public function __construct($desenvolvimento = false)
	{
		if ($desenvolvimento) {
			$this->server = self::SERVER_DSV;
		} 
		
		//$this->urlRed = 'https://' . $this->server . ':8543/REDCentral/autorizacaoinclusaoprocesso';
		$this->urlRed = 'https://' . $this->server . '/REDCentral/autorizacaoinclusaoprocesso';
		
		/*
		$this->nomeMaquinaResponsavelIntervensao = $this->getNomeMaquina();
		$this->nomeMaquina = $this->getNomeMaquina();
		*/
	}
	/*
	public function getXmlAutorizacao()
	{
		$doc = new DOMDocument();
		$root = $doc->createElement('root');
		$doc->appendChild($root);

		$solicitante = $doc->createElement('Solicitante');
		$root->appendChild($solicitante); 
		
		$login = $doc->createAttribute('login');
		$solicitante->appendChild($login);
		$loginTexto = $doc->createTextNode($this->login);
    	$login->appendChild($loginTexto); 
    	
		$ip = $doc->createAttribute('ip');
		$solicitante->appendChild($ip);
		$ipTexto = $doc->createTextNode($this->ip);
    	$ip->appendChild($ipTexto);
    	
    	$sistema = $doc->createAttribute('sistema');
		$solicitante->appendChild($sistema);
		$sistemaTexto = $doc->createTextNode($this->sistema);
    	$sistema->appendChild($sistemaTexto);

		$nomeMaquina = $doc->createAttribute('nomeMaquina');
		$solicitante->appendChild($nomeMaquina);
		$nomeMaquinaTexto = $doc->createTextNode($this->nomeMaquina);
    	$nomeMaquina->appendChild($nomeMaquinaTexto);   
    	
    	$numeroDocumento = $doc->createAttribute('numeroDocumento');
		$solicitante->appendChild($numeroDocumento);
		$numeroDocumentoTexto = $doc->createTextNode($this->numeroDocumento);
    	$numeroDocumento->appendChild($numeroDocumentoTexto); 
		
		return $doc->saveXML($root); 
	}
	*/
	/*
	public function getXml()
	{
		$doc = new DOMDocument();
		$root = $doc->createElement('root');
		$doc->appendChild($root);

		$metadadosInclusaoProcesso = $doc->createElement('MetadadosInclusaoProcesso');
		$root->appendChild($metadadosInclusaoProcesso); 
		
		$dataHoraProducaoConteudo = $doc->createAttribute('dataHoraProducaoConteudo');
		$metadadosInclusaoProcesso->appendChild($dataHoraProducaoConteudo);
		$dataHoraProducaoConteudoTexto = $doc->createTextNode($this->dataHoraProducaoConteudo);
    	$dataHoraProducaoConteudo->appendChild($dataHoraProducaoConteudoTexto); 
    	
		$descricaoTituloDocumento = $doc->createAttribute('descricaoTituloDocumento');
		$metadadosInclusaoProcesso->appendChild($descricaoTituloDocumento);
		$descricaoTituloDocumentoTexto = $doc->createTextNode($this->descricaoTituloDocumento);
    	$descricaoTituloDocumento->appendChild($descricaoTituloDocumentoTexto);

		$numeroTipoSigilo = $doc->createAttribute('numeroTipoSigilo');
		$metadadosInclusaoProcesso->appendChild($numeroTipoSigilo);
		$numeroTipoSigiloTexto = $doc->createTextNode($this->numeroTipoSigilo);
    	$numeroTipoSigilo->appendChild($numeroTipoSigiloTexto);

		$numeroTipoDocumento = $doc->createAttribute('numeroTipoDocumento');
		$metadadosInclusaoProcesso->appendChild($numeroTipoDocumento);
		$numeroTipoDocumentoTexto = $doc->createTextNode($this->numeroTipoDocumento);
    	$numeroTipoDocumento->appendChild($numeroTipoDocumentoTexto);

		$nomeSistemaIntrodutor = $doc->createAttribute('nomeSistemaIntrodutor');
		$metadadosInclusaoProcesso->appendChild($nomeSistemaIntrodutor);
		$nomeSistemaIntrodutorTexto = $doc->createTextNode($this->nomeSistemaIntrodutor);
    	$nomeSistemaIntrodutor->appendChild($nomeSistemaIntrodutorTexto);        	
    	
		$ipMaquinaResponsavelIntervencao = $doc->createAttribute('ipMaquinaResponsavelIntervencao');
		$metadadosInclusaoProcesso->appendChild($ipMaquinaResponsavelIntervencao);
		$ipMaquinaResponsavelIntervencaoTexto = $doc->createTextNode($this->ipMaquinaResponsavelIntervencao);
    	$ipMaquinaResponsavelIntervencao->appendChild($ipMaquinaResponsavelIntervencaoTexto);        	
    	
		$secaoOrigemDocumento = $doc->createAttribute('secaoOrigemDocumento');
		$metadadosInclusaoProcesso->appendChild($secaoOrigemDocumento);
		$secaoOrigemDocumentoTexto = $doc->createTextNode($this->secaoOrigemDocumento);
    	$secaoOrigemDocumento->appendChild($secaoOrigemDocumentoTexto);        	
    	
		$prioridadeReplicacao = $doc->createAttribute('prioridadeReplicacao');
		$metadadosInclusaoProcesso->appendChild($prioridadeReplicacao);
		$prioridadeReplicacaoTexto = $doc->createTextNode($this->prioridadeReplicacao);
    	$prioridadeReplicacao->appendChild($prioridadeReplicacaoTexto);
    	        	
		$espacoDocumento = $doc->createAttribute('espacoDocumento');
		$metadadosInclusaoProcesso->appendChild($espacoDocumento);
		$espacoDocumentoTexto = $doc->createTextNode($this->espacoDocumento);
    	$espacoDocumento->appendChild($espacoDocumentoTexto);        	
    	
		$nomeMaquinaResponsavelIntervensao = $doc->createAttribute('nomeMaquinaResponsavelIntervensao');
		$metadadosInclusaoProcesso->appendChild($nomeMaquinaResponsavelIntervensao);
		$nomeMaquinaResponsavelIntervensaoTexto = $doc->createTextNode($this->nomeMaquinaResponsavelIntervensao);
    	$nomeMaquinaResponsavelIntervensao->appendChild($nomeMaquinaResponsavelIntervensaoTexto);        	
    	
		$indicadorAnotacao = $doc->createAttribute('indicadorAnotacao');
		$metadadosInclusaoProcesso->appendChild($indicadorAnotacao);
		$indicadorAnotacaoTexto = $doc->createTextNode($this->indicadorAnotacao);
    	$indicadorAnotacao->appendChild($indicadorAnotacaoTexto);        	
    	
		$numeroDocumento = $doc->createAttribute('numeroDocumento');
		$metadadosInclusaoProcesso->appendChild($numeroDocumento);
		$numeroDocumentoTexto = $doc->createTextNode($this->numeroDocumento);
    	$numeroDocumento->appendChild($numeroDocumentoTexto);        	
    	
		$dataHoraProtocolo = $doc->createAttribute('dataHoraProtocolo');
		$metadadosInclusaoProcesso->appendChild($dataHoraProtocolo);
		$dataHoraProtocoloTexto = $doc->createTextNode($this->dataHoraProtocolo);
    	$dataHoraProtocolo->appendChild($dataHoraProtocoloTexto);        	
    	
    	$pastaProcesso = $doc->createElement('PastaProcesso');
		$metadadosInclusaoProcesso->appendChild($pastaProcesso); 
		
		$pastaProcessoNumero = $doc->createAttribute('numero');
		$pastaProcesso->appendChild($pastaProcessoNumero);
		$pastaProcessoNumeroTexto = $doc->createTextNode($this->pastaProcessoNumero);
    	$pastaProcessoNumero->appendChild($pastaProcessoNumeroTexto);     
		
    	$secaoDestino = $doc->createElement('SecaoDestino');
		$metadadosInclusaoProcesso->appendChild($secaoDestino); 
		
		$secaoDestinoIdSecao = $doc->createAttribute('idSecao');
		$secaoDestino->appendChild($secaoDestinoIdSecao);
		$secaoDestinoIdSecaoTexto = $doc->createTextNode($this->secaoDestinoIdSecao);
    	$secaoDestinoIdSecao->appendChild($secaoDestinoIdSecaoTexto);     
		
		return $doc->saveXML($root); 
	}	
	*/
	public function getAutorizacao ()
	{
		$xml = $this->_getAutorizacao($this->urlRed,$this->parametros->getXml());
		//var_dump($xml);
		//exit;
		$obj = simplexml_load_string($xml);
		
		if (isset($obj->Mensagem)) {
			throw new Exception('Erro: ' . $obj->Mensagem['codigo'] . ' - ' . $obj->Mensagem['descricao']);
		}
		// var_dump($obj->retornoSolicitacaoInclusao['url']);
		//exit;
		return (string)$obj->retornoSolicitacaoInclusao['url'];
	}
	
	public function incluir (Red_Parametros_Interface $parametros, Red_Metadados_Interface $metadados, $file)
	{
		//echo $this->getXml();
		$this->parametros = $parametros;
		$this->metadados = $metadados;
		
		try {
			$url = $this->getAutorizacao();
			
			$this->xmlSaida = $this->_upload($url,$this->metadados->getXml(),$file, $this->parametros->login, $this->parametros->ip);
			//return $this->xmlSaida;
			//var_dump($this->xmlSaida);
			//exit;
			return $this->montarRetorno();
		} catch (Exception $e) {
			var_dump($e);
		}
	}
	/*
	public function mensagem()
	{
		$xmlRedMensagem = @simplexml_load_string($this->xmlSaida);
		if(@isset($xmlRedMensagem->Mensagem)){
			for($i=0; $i < sizeof($xmlRedMensagem->Mensagem); $i++) {
				$TamArray = sizeof($this->mensagem);
				$this->mensagem[$TamArray]['codigo'] 	= $xmlRedMensagem->Mensagem[$i]['codigo'];
				$this->mensagem[$TamArray]['descricao'] = $xmlRedMensagem->Mensagem[$i]['descricao'];
			}
			$this->existeArquivo = false;
		}
	}	
	*/
	public function montarRetorno()
	{
		
		$obj = simplexml_load_string($this->xmlSaida);
		
		if (isset($obj->Mensagem)) {
			throw new Exception('Erro: ' . $obj->Mensagem['codigo'] . ' - ' . $obj->Mensagem['descricao']);
		}
		
		return array(
			'numeroDocumento' => (string)$obj->retornoConclusaoInclusao['numeroDocumento'],
			'hashConteudo'    => (string)$obj->retornoConclusaoInclusao['hashConteudo'],
			'mensagem'        => 'Codigo' . $obj->retornoConclusaoInclusao->mensagem['codigo'] . $obj->retornoConclusaoInclusao->mensagem['descricao'],
		);
	}	
}
?>