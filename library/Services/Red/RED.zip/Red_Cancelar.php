<?php
class Red_Cancelar extends Red_Abstract implements Red_Interface
{
	const SERVER_PRD            = 'prd.trf1.gov.br';
	const SERVER_DSV            = '172.16.3.179'; 
	public $server				= 'prd.trf1.gov.br'; //desenvolvimento
	
	public $xmlSaida 			= '';
	public $urlSaida 			= array();
	public $mensagem			= array(); 
	public $urlRed 			    = '';//http://' . $this->server . '/REDCentral/autorizacaoRecuperacaoDocumento';
	public $parametros;
	
	public function __construct($desenvolvimento = false)
	{
		if ($desenvolvimento) {
			$this->server = self::SERVER_DSV;
		} 
		
		$this->urlRed = 'http://' . $this->server . '/REDCentral/cancelarDocumento';
	}
	
	public function getAutorizacao()
	{
		$xml = $this->_getAutorizacao($this->urlRed,$this->parametros->getXml());
		$obj = @simplexml_load_string($xml);
		
		if(isset($obj->Mensagem)){	
			throw new Exception('Erro: ' . $obj->Mensagem['codigo'] . ' - ' . $obj->Mensagem['descricao']);
		}
		
		return array(
			'tipoArquivo' => $obj->retornoListaURLArquivoDocumentoXML->retornoURLArquivoDocumentoXML[$i]['tipoArquivo'],
			'url'         => $obj->retornoListaURLArquivoDocumentoXML->retornoURLArquivoDocumentoXML[$i]['url']
		);
	}
	
	public function cancelar (Red_Parametros_Interface $parametros)
	{
		$this->parametros = $parametros;
	//echo $this->getXml();
	
		try {
			$this->getAutorizacao()
			return $this->xmlSaida;
			//return $this->montarRetorno();
		} catch (Exception $e) {
			
		}
	}
	
	public function mensagem()
	{
		$xmlRedMensagem = @simplexml_load_string($this->xmlSaida);
		if(@isset($xmlRedMensagem->Mensagem)){
			for($i=0; $i < sizeof($xmlRedMensagem->Mensagem); $i++) {
				$TamArray = sizeof($this->mensagem);
				$this->mensagem[$TamArray]['codigo'] 	= $xmlRedMensagem->Mensagem[$i]['codigo'];
				$this->mensagem[$TamArray]['descricao'] = $xmlRedMensagem->Mensagem[$i]['descricao'];
			}
			$this->existeArquivo = false;
		}
	}	
	
	public function montarRetorno()
	{
		echo $this->xmlSaida;
		$xmlRedUrl = simplexml_load_string($this->xmlSaida);
		for($i=0; $i < sizeof($xmlRedUrl->retornoListaURLArquivoDocumentoXML->retornoURLArquivoDocumentoXML); $i++) {
			$TamArray = sizeof($this->urlSaida);
			$this->urlSaida[$TamArray]['tipoArquivo'] 	= $xmlRedUrl->retornoListaURLArquivoDocumentoXML->retornoURLArquivoDocumentoXML[$i]['tipoArquivo'];
			$this->urlSaida[$TamArray]['url'] 			= $xmlRedUrl->retornoListaURLArquivoDocumentoXML->retornoURLArquivoDocumentoXML[$i]['url'];
		}
		
		return $this->urlSaida;
	}	
}
?>