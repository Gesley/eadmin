<?php 
error_reporting(E_ALL);
ini_set('display_errors', '1'); 
require_once('Interface.php');
require_once('Abstract.php');
require_once('Red_Recuperar.php');
require_once('Red_Parametros_Interface.php');
require_once('Red_Recuperar_Parametros.php');
require_once('Red_Recuperar.php');

$parametros = new Red_Recuperar_Parametros();
$parametros->ip = '172.16.5.62';
$parametros->login = 'TR224PS';
$parametros->sistema = 'JURIS';
$parametros->nomeMaquina = 'DISAD010-TRF1';
$parametros->numeroDocumento = '43020100284';
$red = new Red_Recuperar(true);

echo '<pre>';
var_dump($red->recuperar($parametros));


echo 'erro';

var_dump($red);
