<?php
interface Red_Parametros_Interface 
{
	public function getXml();
}
?>