<?php
interface Red_Metadados_Interface 
{
	public function getXml();
}
?>